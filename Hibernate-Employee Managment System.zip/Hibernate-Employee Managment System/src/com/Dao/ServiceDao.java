package com.Dao;

public class ServiceDao implements EmployeeServiceDao{

	@Override
	public void createEmployeeOnlyInDao() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createDepartmentWithEmployeeInDao() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createDepartmentOnlyInDao() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readAllDetailsInDao() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readEmployeeWithDepartmentIdInDao() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readDepartmentWithDepartmentIdInDao() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateAllDetailsInDao() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEmployeeWithDepartmentIdInDao() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDepartmentWithDepartmentIdInDao() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllDetails() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEmployeeWithDepartmentIdInDao() {
		// TODO Auto-generated method stub
		
	}

}
