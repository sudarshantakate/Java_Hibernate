package com;

import com.Service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public void createEmployeeOnlyInService() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createDepartmentWithEmployeeInService() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createDepartmentOnlyInService() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readAllDetailsInService() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readEmployeeWithDepartmentIdInService() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readDepartmentWithDepartmentIdInService() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateAllDetailsInService() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEmployeeWithDepartmentIdInService() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDepartmentWithDepartmentIdInService() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllDetails() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEmployeeWithDepartmentIdInService() {
		// TODO Auto-generated method stub
		
	}

}
